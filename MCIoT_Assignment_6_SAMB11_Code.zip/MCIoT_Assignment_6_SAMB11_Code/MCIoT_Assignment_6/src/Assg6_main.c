#include <asf.h>
#include "platform.h"
#include "at_ble_api.h"
#include "console_serial.h"
#include "timer_hw.h"
#include "ble_manager.h"
#include "ble_utils.h"
#include "button.h"
#include "startup_template_app.h"
#include "samb11_xplained_pro.h"
#include <string.h>

#define ENABLE_TX_FOR_LOOPBACK

struct uart_module uart_instance;

#ifdef ENABLE_TX_FOR_LOOPBACK
struct dma_resource uart_dma_resource_tx;
#endif
struct dma_resource uart_dma_resource_rx;

#define BUFFER_LEN    4
static uint8_t string[BUFFER_LEN];

#ifdef ENABLE_TX_FOR_LOOPBACK
struct dma_descriptor example_descriptor_tx;
#endif
struct dma_descriptor example_descriptor_rx;

volatile at_ble_status_t status;

at_ble_handle_t htpt_conn_handle;

volatile bool Timer_Flag = false;

volatile bool Temp_Notification_Flag = false;

uint8_t Temp_Data_Read_In_Progress = 0;
uint8_t is_next_temp_data_mantissa = 0;

uint8_t led_data = 0;
uint8_t temp_sign_data = 0;
uint8_t temp_mantissa_data = 0;
uint8_t temp_exponent_data = 0;

struct gpio_config config_gpio_pin;

#define LEUART_LED_DATA_IDENTIFIER      0
#define LEUART_TEMP_DATA_IDENTIFIER     1

void read_uart_data(uint8_t *rdata_ptr)
{
	int count = 0;
	while (count < BUFFER_LEN)
	{
		if (Temp_Data_Read_In_Progress == 0)
		{
			if ((*rdata_ptr >> 7) == LEUART_LED_DATA_IDENTIFIER)
			{
				/* LED Data */
				led_data = *rdata_ptr & 0x7F;

				/* LED Data of 0 indicates darkness, so the LED will be turned ON (if it is OFF).
				** LED Data of 1 indicates brightness, so the LED will turned OFF (if it is ON)
				*/

				if (led_data != 7)
				{
					if (led_data == 0)
					{
						/* Turn On the LED */
						gpio_pin_set_config(PIN_LP_GPIO_22, &config_gpio_pin);
					
						LED_On(PIN_LP_GPIO_22);
					}
					else
					{
						/* Turn Off the LED */
						LED_Off(PIN_LP_GPIO_22);
					}	
				}
				
				
			}
			else if ((*rdata_ptr >> 7) == LEUART_TEMP_DATA_IDENTIFIER)
			{
				Temp_Data_Read_In_Progress = 1;
				temp_sign_data = *rdata_ptr & 0x7F;
				is_next_temp_data_mantissa = 1;
			}
			else
			{
				/* Invalid Data Identifier */
			}
		}
		else
		{
			if (1 == is_next_temp_data_mantissa)
			{
				temp_mantissa_data = *rdata_ptr;
				is_next_temp_data_mantissa = 0;
			}
			else
			{
				temp_exponent_data = *rdata_ptr;
				Temp_Data_Read_In_Progress = 0;
			}

		}
		
		count++;
		rdata_ptr++;
	}
	
    
}

#ifdef ENABLE_TX_FOR_LOOPBACK
static void transfer_done_tx(struct dma_resource* const resource )
{
    dma_start_transfer_job(&uart_dma_resource_rx);
}
#endif

static void transfer_done_rx(struct dma_resource* const resource )
{    
	uint8_t *ptr_string = string;
    dma_start_transfer_job(&uart_dma_resource_tx);
	
	read_uart_data(ptr_string);
}

#ifdef ENABLE_TX_FOR_LOOPBACK
static void configure_dma_resource_tx(struct dma_resource *resource)
{
    struct dma_resource_config config;

    dma_get_config_defaults(&config);

    config.des.periph = UART1TX_DMA_PERIPHERAL;
    config.des.enable_inc_addr = false;
    config.src.periph = UART1TX_DMA_PERIPHERAL;
    
    dma_allocate(resource, &config);
}

static void setup_transfer_descriptor_tx(struct dma_descriptor *descriptor)
{
    dma_descriptor_get_config_defaults(descriptor);

    descriptor->buffer_size = BUFFER_LEN;
    descriptor->read_start_addr = (uint32_t)string;
    descriptor->write_start_addr = 
        (uint32_t)(&uart_instance.hw->TRANSMIT_DATA.reg);
}
#endif

static void configure_dma_resource_rx(struct dma_resource *resource)
{
    struct dma_resource_config config;

    dma_get_config_defaults(&config);

    config.src.periph = UART1RX_DMA_PERIPHERAL;
    config.src.enable_inc_addr = false;
    config.src.periph_delay = 1;

    dma_allocate(resource, &config);
}

static void setup_transfer_descriptor_rx(struct dma_descriptor *descriptor)
{
    dma_descriptor_get_config_defaults(descriptor);

    descriptor->buffer_size = BUFFER_LEN;
    descriptor->read_start_addr =
        (uint32_t)(&uart_instance.hw->RECEIVE_DATA.reg);
    descriptor->write_start_addr = (uint32_t)string;
}

static void configure_usart(void)
{
    struct uart_config atsamb11_uart_config;

    uart_get_config_defaults(&atsamb11_uart_config);
    /*	Defaults 
        config->baud_rate = 115200;
        config->data_bits = UART_8_BITS;
        config->stop_bits = UART_1_STOP_BIT;
        config->parity = UART_NO_PARITY;
        config->flow_control = false;
        */

    atsamb11_uart_config.baud_rate = 9600;
    atsamb11_uart_config.pin_number_pad[0] = EDBG_CDC_SERCOM_PIN_PAD0;
    atsamb11_uart_config.pin_number_pad[1] = EDBG_CDC_SERCOM_PIN_PAD1;
    atsamb11_uart_config.pin_number_pad[2] = EDBG_CDC_SERCOM_PIN_PAD2;
    atsamb11_uart_config.pin_number_pad[3] = EDBG_CDC_SERCOM_PIN_PAD3;
    atsamb11_uart_config.pinmux_sel_pad[0] = EDBG_CDC_SERCOM_MUX_PAD0;
    atsamb11_uart_config.pinmux_sel_pad[1] = EDBG_CDC_SERCOM_MUX_PAD1;
    atsamb11_uart_config.pinmux_sel_pad[2] = EDBG_CDC_SERCOM_MUX_PAD2;
    atsamb11_uart_config.pinmux_sel_pad[3] = EDBG_CDC_SERCOM_MUX_PAD3;

    while (uart_init(&uart_instance,
                EDBG_CDC_MODULE, &atsamb11_uart_config) != STATUS_OK) {
    }

#ifdef ENABLE_TX_FOR_LOOPBACK
    uart_enable_transmit_dma(&uart_instance);
#endif
    uart_enable_receive_dma(&uart_instance);
}

static void configure_dma_callback(void)
{
	
#ifdef ENABLE_TX_FOR_LOOPBACK
    dma_register_callback(&uart_dma_resource_tx, transfer_done_tx, DMA_CALLBACK_TRANSFER_DONE);
#endif
    dma_register_callback(&uart_dma_resource_rx, transfer_done_rx, DMA_CALLBACK_TRANSFER_DONE);

#ifdef ENABLE_TX_FOR_LOOPBACK
    dma_enable_callback(&uart_dma_resource_tx, DMA_CALLBACK_TRANSFER_DONE);
#endif
    dma_enable_callback(&uart_dma_resource_rx, DMA_CALLBACK_TRANSFER_DONE);

    NVIC_EnableIRQ(PROV_DMA_CTRL0_IRQn);
}

static void ble_advertise (void)
{
    printf("\n Start Advertising");
    status = ble_advertisement_data_set();
    if(status != AT_BLE_SUCCESS)
    {
        printf("\n\r## Advertisement data set failed : error %x",status);
        while(1);
    }
    /* Start of advertisement */
    status = at_ble_adv_start(AT_BLE_ADV_TYPE_UNDIRECTED,
            AT_BLE_ADV_GEN_DISCOVERABLE,
            NULL,
            AT_BLE_ADV_FP_ANY,
            1000,
            655,
            0);

    if(status != AT_BLE_SUCCESS)
    {
        printf("\n\r## Advertisement data set failed : error %x",status);
        while(1);
    }
}

/* Callback registered for AT_BLE_CONNECTED event*/ 
static at_ble_status_t ble_paired_cb (void *param) 
{ 
    at_ble_pair_done_t *pair_params = param; 
    printf("\n Application paired "); 
    /* Enable the HTP Profile */ 
    printf("\n Enable health temperature service "); 
    status = at_ble_htpt_enable(pair_params->handle, HTPT_CFG_INTERM_MEAS_NTF); 
    if(status != AT_BLE_SUCCESS)
    { 
        printf("*** Failure in HTP Profile Enable"); 
        while(true); 
    }

    ALL_UNUSED(param); 
    return AT_BLE_SUCCESS; 
}

/* Callback registered for AT_BLE_DISCONNECTED event */ 
static at_ble_status_t ble_disconnected_cb (void *param) 
{ 
    printf("\n Application disconnected "); 
    ble_advertise(); 
    ALL_UNUSED(param);
    return AT_BLE_SUCCESS; 
}

static const ble_event_callback_t app_gap_cb[] = {
    NULL, // AT_BLE_UNDEFINED_EVENT
    NULL, // AT_BLE_SCAN_INFO
    NULL, // AT_BLE_SCAN_REPORT
    NULL, // AT_BLE_ADV_REPORT
    NULL, // AT_BLE_RAND_ADDR_CHANGED
    NULL, // AT_BLE_CONNECTED
    ble_disconnected_cb, // AT_BLE_DISCONNECTED
    NULL, // AT_BLE_CONN_PARAM_UPDATE_DONE
    NULL, // AT_BLE_CONN_PARAM_UPDATE_REQUEST
    ble_paired_cb, // AT_BLE_PAIR_DONE
    NULL, // AT_BLE_PAIR_REQUEST
    NULL, // AT_BLE_SLAVE_SEC_REQUEST
    NULL, // AT_BLE_PAIR_KEY_REQUEST
    NULL, // AT_BLE_ENCRYPTION_REQUEST
    NULL, // AT_BLE_ENCRYPTION_STATUS_CHANGED
    NULL, // AT_BLE_RESOLV_RAND_ADDR_STATUS
    NULL, // AT_BLE_SIGN_COUNTERS_IND
    NULL, // AT_BLE_PEER_ATT_INFO_IND
    NULL // AT_BLE_CON_CHANNEL_MAP_IND
};

static at_ble_status_t app_htpt_cfg_indntf_ind_handler(void *params)
{
    at_ble_htpt_cfg_indntf_ind_t htpt_cfg_indntf_ind_params;
    memcpy((uint8_t *)&htpt_cfg_indntf_ind_params, params, sizeof(at_ble_htpt_cfg_indntf_ind_t));
    if (htpt_cfg_indntf_ind_params.ntf_ind_cfg == 0x03)
    {
        printf("Started HTP Temperature Notification");
        Temp_Notification_Flag = true;
    }
    else
    {
        printf("HTP Temperature Notification Stopped");
        Temp_Notification_Flag = false;
    }
    return AT_BLE_SUCCESS;
}

static const ble_event_callback_t app_htpt_handle[] = { 
    NULL, // AT_BLE_HTPT_CREATE_DB_CFM 
    NULL, // AT_BLE_HTPT_ERROR_IND 
    NULL, // AT_BLE_HTPT_DISABLE_IND 
    NULL, // AT_BLE_HTPT_TEMP_SEND_CFM 
    NULL, // AT_BLE_HTPT_MEAS_INTV_CHG_IND 
    app_htpt_cfg_indntf_ind_handler, // AT_BLE_HTPT_CFG_INDNTF_IND 
    NULL, // AT_BLE_HTPT_ENABLE_RSP 
    NULL, // AT_BLE_HTPT_MEAS_INTV_UPD_RSP 
    NULL // AT_BLE_HTPT_MEAS_INTV_CHG_REQ 
};

/* Register GAP callbacks at BLE manager level*/ 
static void register_ble_callbacks (void) 
{ 
    /* Register GAP Callbacks */ 
    printf("\nRegister bluetooth events callbacks"); 
    status = ble_mgr_events_callback_handler(
            REGISTER_CALL_BACK, 
            BLE_GAP_EVENT_TYPE,
            app_gap_cb); 
    if (status != true) 
    { 
        printf("\n##Error when Registering SAMB11 gap callbacks"); 
    } 

    status = ble_mgr_events_callback_handler(REGISTER_CALL_BACK, 
            BLE_GATT_HTPT_EVENT_TYPE,app_htpt_handle); 
    if (status != true) 
    { 
        printf("\n##Error when Registering SAMB11 htpt callbacks"); 
    }
}

static void htp_init (void) 
{ 
    printf("\nInit Health temperature service "); 

    /* Create htp service in GATT database*/ 
    status = at_ble_htpt_create_db( 
            HTPT_TEMP_TYPE_CHAR_SUP, 
            HTP_TYPE_ARMPIT, 
            1, 
            30, 
            1, 
            HTPT_AUTH, 
            &htpt_conn_handle); 
    if (status != AT_BLE_SUCCESS)
    { 
        printf("HTP Data Base creation failed"); 
        while(true); 
    } 
}

/* Timer callback */ 
static void timer_callback_handler(void) 
{ 
    /* Stop timer */ 
    hw_timer_stop(); 

    /* Set timer Alarm flag */ 
    Timer_Flag = true; 

    /* Restart Timer */ 
    hw_timer_start(10);
}

/* Sending the temperature value after reading it from IO1 Xplained Pro */ 
static void htp_temperature_send(void) 
{ 
    at_ble_prf_date_time_t timestamp; 
    float temperature; 

    /* Read Temperature Value from IO1 Xplained Pro */ 
    //temperature = at30tse_read_temperature(); 
    
    if (temp_sign_data == 0)
    {
        /* Positive Temperature */
        temperature = temp_mantissa_data + (float)temp_exponent_data/10;
    }
    else
    {
        temperature = -(temp_mantissa_data + (float)temp_exponent_data/10);
    }

#ifdef HTPT_FAHRENHEIT 
    //temperature = (((temperature * 9.0)/5.0) + 32.0); 
#endif 

    /* Read Temperature Value from IO1 Xplained Pro */ 
    timestamp.day = 1; 
    timestamp.hour = 9; 
    timestamp.min = 2; 
    timestamp.month = 8; 
    timestamp.sec = 36; 
    timestamp.year = 15; 

    /* Read Temperature Value from IO1 Xplained Pro */ 
    if(at_ble_htpt_temp_send(convert_ieee754_ieee11073_float((float)temperature), &timestamp, 
#ifdef HTPT_FAHRENHEIT 
                (at_ble_htpt_temp_flags)(HTPT_FLAG_FAHRENHEIT | HTPT_FLAG_TYPE), 
#else 
                (at_ble_htpt_temp_flags)(HTPT_FLAG_CELSIUS | HTPT_FLAG_TYPE), 
#endif 
                HTP_TYPE_ARMPIT, 
                1 ) == AT_BLE_SUCCESS) 
    { 
#ifdef HTPT_FAHRENHEIT 
        printf("\nTemperature: %d Fahrenheit", (uint16_t)temperature); 
#else
        printf("\nTemperature: %d Deg Celsius", (uint16_t)temperature); 
#endif 
    } 
}

void at_samb11_uart_setup(void)
{
    configure_usart();

#ifdef ENABLE_TX_FOR_LOOPBACK
    configure_dma_resource_tx(&uart_dma_resource_tx);
#endif
    configure_dma_resource_rx(&uart_dma_resource_rx);

#ifdef ENABLE_TX_FOR_LOOPBACK
    setup_transfer_descriptor_tx(&example_descriptor_tx);
#endif
    setup_transfer_descriptor_rx(&example_descriptor_rx);

#ifdef ENABLE_TX_FOR_LOOPBACK
    dma_add_descriptor(&uart_dma_resource_tx, &example_descriptor_tx);
#endif
    dma_add_descriptor(&uart_dma_resource_rx, &example_descriptor_rx);

    configure_dma_callback();
}

void configure_led_gpio(void)
{
	
	gpio_get_config_defaults(&config_gpio_pin);
	config_gpio_pin.direction  = GPIO_PIN_DIR_OUTPUT;
	config_gpio_pin.input_pull = GPIO_PIN_PULL_UP; /* GPIO_PIN_PULL_UP, GPIO_PIN_PULL_DOWN */
	
}

int main (void)
{
    platform_driver_init();
    acquire_sleep_lock();
    
    /* Initialize serial console */
    serial_console_init();
    
    /* Hardware timer */
    hw_timer_init();

    /* Register the callback */ 
    hw_timer_register_callback(timer_callback_handler); 

    /* Start timer */ 
    hw_timer_start(1);

    printf("\n\rSAMB11 BLE Application");
	
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
	
	system_clock_config(CLOCK_RESOURCE_XO_26_MHZ, CLOCK_FREQ_26_MHZ);

    at_samb11_uart_setup();
	
	configure_led_gpio();

    /* initialize the BLE chip and Set the Device Address */
    ble_device_init(NULL); 

    /* Initialize htp service */
    htp_init();

    /* Register Bluetooth events Callbacks */ 
    register_ble_callbacks();

    /* Start Advertising process */ 
    ble_advertise();
	
	dma_start_transfer_job(&uart_dma_resource_rx);

    while(true) {
        ble_event_task(655);
        if (Timer_Flag & Temp_Notification_Flag) 
        { 
            htp_temperature_send(); 
        }
    }
}

