#ifndef _MCIOT_ADC_H_
#define _MCIOT_ADC_H_
#endif

/************************************ INCLUDES **************************************/

#include "em_dma.h"
#include "dmactrl.h"

/************************************ INCLUDES **************************************/

/************************************* MACROS ***************************************/

#define DMA_CHANNEL_ADC       		0
#define ADC_SAMPLE_TRANSFER_SIZE	1
#define DMA_CHANNEL_LEUART       	0

/* DMA Channel Configuration Macros */
#define DMA_SIGNAL_SOURCE			DMAREQ_ADC0_SINGLE

/* DMA Channel Descriptor Macros */
#ifdef USE_DMA_FOR_ADC
#define DMA_DST_INCREMENT_SIZE		dmaDataInc2
#define DMA_SRC_INCREMENT_SIZE		dmaDataIncNone
#define DMA_TRANSFER_SIZE			dmaDataSize2
#define DMA_TRANSFER_ARBRATE		dmaArbitrate1
#else
#define DMA_DST_INCREMENT_SIZE		dmaDataIncNone
#define DMA_SRC_INCREMENT_SIZE		dmaDataInc1
#define DMA_TRANSFER_SIZE			dmaDataSize1
#define DMA_TRANSFER_ARBRATE		dmaArbitrate1
#endif

/************************************* MACROS ***************************************/

/************************************ GLOBALS ***************************************/

DMA_CB_TypeDef dma_cb_fn;

volatile uint16_t ADCDataRAMBuffer[ADC_SAMPLES];
volatile uint16_t *p_ADCDataRAMBuffer;

volatile uint8_t LEUARTDataRAMBuffer[4];
volatile uint8_t *p_LEUARTDataRAMBuffer;

/************************************ GLOBALS ***************************************/

/****************************** FUNCTION PROTOTYPES *********************************/

void DMA_SetUp(void);

#ifdef USE_DMA_FOR_ADC
void ADC_dma_ch0_TransferComplete(uint32_t channel, bool primary, void *user);
#else
void LEUART_dma_ch0_TransferComplete(uint32_t channel, bool primary, void *user);
#endif

void WriteDataToLEUARTDMA(LEUART_CIRC_BUFFER *leuart_circ_buff);
/****************************** FUNCTION PROTOTYPES *********************************/
