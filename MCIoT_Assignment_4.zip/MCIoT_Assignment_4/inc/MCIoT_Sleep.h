#ifndef _MCIOT_SLEEP_H_
#define _MCIOT_SLEEP_H_
#endif

/************************************ INCLUDES **************************************/

#include "em_int.h"

/************************************ INCLUDES **************************************/

/****************************** FUNCTION PROTOTYPES *********************************/

void blockSleepMode(ENERGY_MODES e_letimer_energy_modes);

void unblockSleepMode(ENERGY_MODES e_letimer_energy_modes);

void Sleep(void);

/****************************** FUNCTION PROTOTYPES *********************************/
