#ifndef _MCIOT_GPIO_H_
#define _MCIOT_GPIO_H_
#endif

/************************************ INCLUDES **************************************/

#include "em_gpio.h"

/************************************ INCLUDES **************************************/

/************************************* MACROS ***************************************/

/* LED GPIO port name and pin */
#define LED0_1_GPIO_PORT 			gpioPortE
#define LED0_GPIO_PIN				2
#define LED1_GPIO_PIN				3

/************************************* MACROS ***************************************/

/****************************** FUNCTION PROTOTYPES *********************************/

void GPIO_SetUp(void);

void LED_On(GPIO_Port_TypeDef port, unsigned int pin);

void LED_Off(GPIO_Port_TypeDef port, unsigned int pin);

/****************************** FUNCTION PROTOTYPES *********************************/
