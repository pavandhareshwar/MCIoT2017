/*****************************************************************************
 * @file 	MCIoT_DMA.c
 * @brief 	This file describes the functions pertaining to DMA setup and
 * 			callback function.
 * @author 	Pavan Dhareshwar
 * @version 1.0
 ******************************************************************************
 * @section License
 * <b>(C) Copyright 2013 Energy Micro AS, http://www.energymicro.com</b>
 *******************************************************************************
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 * 4. The source and compiled code may only be used on Energy Micro "EFM32"
 *    microcontrollers and "EFR4" radios.
 *
 * DISCLAIMER OF WARRANTY/LIMITATION OF REMEDIES: Energy Micro AS has no
 * obligation to support this Software. Energy Micro AS is providing the
 * Software "AS IS", with no express or implied warranties of any kind,
 * including, but not limited to, any implied warranties of merchantability
 * or fitness for any particular purpose or warranties against infringement
 * of any proprietary rights of a third party.
 *
 * Energy Micro AS will not be liable for any consequential, incidental, or
 * special damages, or any other relief, or for any claim by any third party,
 * arising from your use of this Software.
 *
 ************************************************************************************/

/************************************ INCLUDES **************************************/
#include <stdint.h>
#include <stdbool.h>
#include "MCIoT_main.h"
#include "MCIoT_ADC.h"
#include "MCIoT_DMA.h"
#include "MCIoT_CMU.h"
#include "MCIoT_GPIO.h"
#include "MCIoT_Sleep.h"

/************************************************************************************
 * @function 	DMA_SetUp
 * @params 		None
 * @brief 		Configures the DMA.
 ************************************************************************************/
void DMA_SetUp(void)
{
	DMA_Init_TypeDef        dmaInit; 	/* SetUp basic operations of the DMA peripherals */
	DMA_CfgChannel_TypeDef  chnlCfg; 	/* Configure DMA channels */
	DMA_CfgDescr_TypeDef    descrCfg;	/* Configure DMA descriptors */

	/* Initializing the DMA */
	dmaInit.hprot        = 0;
	dmaInit.controlBlock = (DMA_DESCRIPTOR_TypeDef *)dmaControlBlock;

	DMA_Init(&dmaInit);

	/* Setting up call-back function */
	/* Callback function is DMA's version of interrupt handling function */
	dma_cb_fn.cbFunc  = (DMA_FuncPtr_TypeDef)ADC_dma_ch0_TransferComplete;
	dma_cb_fn.userPtr = NULL;
	//dma_cb_fn.primary = true;

	/* Setting up channel */
	chnlCfg.highPri   = true;						/* channel priority is high */
	chnlCfg.enableInt = true;
	chnlCfg.select    = DMA_SIGNAL_SOURCE; 			/* ADC DMA request to use the ADC Single DMA request line */
	chnlCfg.cb        = &dma_cb_fn;
	DMA_CfgChannel(DMA_CHANNEL_ADC, &chnlCfg);

	/* Setting up channel descriptor */
	descrCfg.dstInc  = DMA_DST_INCREMENT_SIZE;		/* Increment dst address by 2 bytes */
	descrCfg.srcInc  = DMA_SRC_INCREMENT_SIZE;		/* Do not increment src address */
	descrCfg.size    = DMA_TRANSFER_SIZE;			/* Transfer size of 2 bytes */
	descrCfg.arbRate = DMA_TRANSFER_ARBRATE;		/* ADC DMA arbitration bit set to 0 */
	descrCfg.hprot   = 0;

	DMA_CfgDescr(DMA_CHANNEL_ADC, true, &descrCfg);
}

/************************************************************************************
 * @function 	ADCdmach0TransferComplete
 * @params 		[in] channel 	- (uint32_t) DMA channel
 * 				[in] primary 	- (bool) primary/alternate DMA descriptor
 * 				[in] user		- (void *)
 * @brief 		Callback function for DMA.
 ************************************************************************************/
void ADC_dma_ch0_TransferComplete(uint32_t channel, bool primary, void *user)
{

	float average = 0.0;

	/* Turn off ADC */
	ADC0->CMD |= ADC_CMD_SINGLESTOP;

	/* Disable clock to ADC0 */
	CMU_ClockEnable(cmuClock_ADC0, false); /* To enable clock to ADC0 */

	unblockSleepMode(ADC_EM);

	average = compute_adc_data_average();

	if ((TEMPERATURE_LOWER_LIMIT <= average)  && (average <= TEMPERATURE_UPPER_LIMIT))
	{
		/* Turning off LED1 */
		LED_Off(LED0_1_GPIO_PORT, LED1_GPIO_PIN);
	}
	else
	{
		/* Turning on LED1 */
		LED_On(LED0_1_GPIO_PORT, LED1_GPIO_PIN);
	}

}
